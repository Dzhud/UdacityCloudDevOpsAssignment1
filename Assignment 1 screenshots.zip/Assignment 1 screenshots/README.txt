The project website is accessible to anyone on the Internet via a web browser.

Site's URL
http://my-588357402884-bucket.s3-website-us-east-1.amazonaws.com

CloudFront endpoint URL
https://d31lb6ea1pu6he.cloudfront.net/